N_("GTK+ Version");
N_("GDK Backend");
N_("Prefix");
N_("X display");
N_("RGBA visual");
N_("Composited");
N_("GL Version");
N_("GL Vendor");
