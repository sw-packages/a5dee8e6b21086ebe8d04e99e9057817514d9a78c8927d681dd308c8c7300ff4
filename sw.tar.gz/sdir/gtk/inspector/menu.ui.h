N_("Label");
N_("Action");
N_("Target");
N_("Icon");
