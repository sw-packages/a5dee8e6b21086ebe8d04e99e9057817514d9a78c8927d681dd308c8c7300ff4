N_("Type");
N_("Self 1");
N_("Cumulative 1");
N_("Self 2");
N_("Cumulative 2");
N_("Self");
N_("Cumulative");
N_("Enable statistics with GOBJECT_DEBUG=instance-count");
