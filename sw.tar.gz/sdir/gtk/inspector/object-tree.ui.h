N_("Object");
N_("Name");
N_("Label");
N_("Style Classes");
