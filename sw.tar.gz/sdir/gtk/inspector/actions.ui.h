N_("Prefix");
N_("Name");
N_("Enabled");
N_("Parameter Type");
N_("State");
