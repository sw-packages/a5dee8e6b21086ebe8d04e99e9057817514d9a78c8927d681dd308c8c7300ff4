N_("Path");
N_("Count");
N_("Size");
N_("Name:");
N_("Type:");
N_("Size:");
